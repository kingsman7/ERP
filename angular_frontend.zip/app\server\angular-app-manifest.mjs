
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "preload": [
      "chunk-EIGSZNSG.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "redirectTo": "/app/dashboard",
    "route": "/app"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/change-password"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/dashboard"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/inventory"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/kardex"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/logistics"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/purchases"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/sales-pos"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/quotes"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/mrp"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/crm"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/treasury"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/accounting"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/cash-closing"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/users"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/audit-log"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/backups"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/manual"
  },
  {
    "renderMode": 1,
    "preload": [
      "chunk-VTNKP4EA.js",
      "chunk-W5XOX3UT.js",
      "chunk-JNNG3DOQ.js",
      "chunk-3IYZ4TVY.js",
      "chunk-HKGPK7Q6.js"
    ],
    "route": "/app/company-admin"
  },
  {
    "renderMode": 2,
    "redirectTo": "/",
    "route": "/**"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 37017, hash: '74d21fb2af38f8f9e6622d2dcc2ac6a8b4aaf231b7dd066cd7732124b4b6a8e9', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 23668, hash: 'c14881e71a8344bebc6a256cf2399a46b3074de4ea70533ec7f4374ad7b69a8f', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'index.html': {size: 65036, hash: '0d1ebde8285ffa68d33c1f9dc72acf103e808a0093b712e7b81ffff0012c7eb1', text: () => import('./assets-chunks/index_html.mjs').then(m => m.default)},
    'styles-WQPRDN3P.css': {size: 160745, hash: '35k+Bz0jQGw', text: () => import('./assets-chunks/styles-WQPRDN3P_css.mjs').then(m => m.default)}
  },
};
