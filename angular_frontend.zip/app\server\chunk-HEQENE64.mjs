import './polyfills.server.mjs';
import{a as C}from"./chunk-4CWRFFNI.mjs";import{i as I}from"./chunk-URXW6BN4.mjs";import{Ab as v,M as x,R as y,Y as A,a as m,b as R,ea as S}from"./chunk-PGC3HUBV.mjs";var E=class b{injector=y(A);get stateService(){return this.injector.get(I)}CONFIG_KEY="Helameb_email_config_v1";ALERTS_KEY="Helameb_email_alerts_v1";config=S(this.loadInitialConfig());sentAlerts=S(this.loadInitialAlerts());isSending=S(!1);reorderItems=v(()=>{let t=this.stateService.products(),o=this.stateService.boms(),r=this.stateService.bcvState().usdRate,n=[];for(let e of t){if(e.status!=="ACTIVE")continue;let a=e.minStock||5,i=e.reorderPoint??Math.max(Math.ceil(a*1.5),a+5),s=e.safetyStock??a,c=e.totalStock,d=o.filter(g=>g.items.some(p=>p.rawMaterialProductId===e.id)).length,l=d>0||e.category==="MATERIA_PRIMA"||e.category==="INSUMOS"||e.category==="LUBRICANTES";if(c<=i){let g=Math.max(0,i-c),p=e.reorderQuantity||Math.max(g+s,20),f=Number((p*e.costPrice).toFixed(2)),h=Number((f*r).toFixed(2)),u="REORDER_REQUIRED";c<=a?u="CRITICAL":c<=i*.75&&(u="WARNING"),n.push({product:e,currentStock:c,reorderPoint:i,minStock:a,deficit:g,suggestedOrderQty:p,estimatedCostUsd:f,estimatedCostVes:h,severity:u,isRawMaterial:l,associatedBomsCount:d})}}return n.sort((e,a)=>e.severity==="CRITICAL"&&a.severity!=="CRITICAL"?-1:a.severity==="CRITICAL"&&e.severity!=="CRITICAL"?1:a.deficit-e.deficit)});criticalCount=v(()=>this.reorderItems().filter(t=>t.severity==="CRITICAL").length);reorderCount=v(()=>this.reorderItems().length);constructor(){this.sentAlerts().length===0&&this.seedInitialAlerts()}loadInitialConfig(){try{let t=localStorage.getItem(this.CONFIG_KEY);if(t)return JSON.parse(t)}catch{}return{enabled:!0,recipients:["ae.barrios@hotmail.com","compras@empresa.com","gerencia.mrp@empresa.com"],senderName:"Helameb MRP Alert Center",senderEmail:"mrp-alerts@Helameb.io",smtpHost:"smtp.sendgrid.net",smtpPort:587,useTls:!0,alertOnReorderPoint:!0,alertOnCriticalStock:!0,autoTriggerOnProduction:!0,autoTriggerOnSales:!0,includeCostValuation:!0,includePreferredSupplier:!0,dailyDigestOnly:!1}}loadInitialAlerts(){try{let t=localStorage.getItem(this.ALERTS_KEY);if(t)return JSON.parse(t)}catch{}return[]}saveConfigToStorage(){try{localStorage.setItem(this.CONFIG_KEY,JSON.stringify(this.config()))}catch(t){console.warn("Failed to persist email config",t)}}saveAlertsToStorage(){try{localStorage.setItem(this.ALERTS_KEY,JSON.stringify(this.sentAlerts()))}catch(t){console.warn("Failed to persist email alerts log",t)}}updateConfig(t){this.config.update(o=>m(m({},o),t)),this.saveConfigToStorage(),this.stateService.notify("success","Configuraci\xF3n de Email Guardada","Par\xE1metros de notificaci\xF3n y destinatarios actualizados.")}addRecipient(t){let o=t.trim().toLowerCase();return!o||!o.includes("@")||!o.includes(".")?(this.stateService.notify("warning","Email Inv\xE1lido","Ingrese una direcci\xF3n de correo electr\xF3nico v\xE1lida."),!1):this.config().recipients.includes(o)?(this.stateService.notify("info","Ya Registrado","El destinatario ya se encuentra en la lista."),!1):(this.config.update(r=>R(m({},r),{recipients:[...r.recipients,o]})),this.saveConfigToStorage(),this.stateService.notify("success","Destinatario A\xF1adido",`${o} agregado a las alertas autom\xE1ticas.`),!0)}removeRecipient(t){this.config.update(o=>R(m({},o),{recipients:o.recipients.filter(r=>r!==t)})),this.saveConfigToStorage()}checkAndTriggerReorderAlerts(t="INVENTORY_SCAN",o){let r=this.config();if(!r.enabled||t==="MRP_CONSUMPTION"&&!r.autoTriggerOnProduction||t==="SALE_POS"&&!r.autoTriggerOnSales)return 0;let n=this.reorderItems();if(n.length===0)return 0;let e=0,a=new Date().toISOString().replace("T"," ").substring(0,19),i=[];for(let s of n){if(this.sentAlerts().some(l=>l.productSku===s.product.sku&&l.triggerReason===t&&Date.now()-new Date(l.timestamp).getTime()<9e5)&&t!=="MANUAL_TRIGGER")continue;let d=this.createAlertLog(s,t,o,a);i.push(d),e++}if(i.length>0){this.sentAlerts.update(d=>[...i,...d].slice(0,200)),this.saveAlertsToStorage();let s=i.map(d=>d.productName).slice(0,2).join(", "),c=i.length>2?` (+${i.length-2} m\xE1s)`:"";this.stateService.notify("warning",`Alerta Email MRP (${e} enviadas)`,`Se enviaron notificaciones a ${r.recipients.length} destinatarios para: ${s}${c}.`)}return e}sendManualAlert(t,o="MANUAL_TRIGGER"){let r=this.config(),n=this.stateService.bcvState().usdRate,e=t.minStock||5,a=t.reorderPoint??Math.max(Math.ceil(e*1.5),e+5),i=t.safetyStock??e,s=t.totalStock,c=Math.max(0,a-s),d=t.reorderQuantity||Math.max(c+i,20),l=Number((d*t.costPrice).toFixed(2)),g=Number((l*n).toFixed(2)),p={product:t,currentStock:s,reorderPoint:a,minStock:e,deficit:c,suggestedOrderQty:d,estimatedCostUsd:l,estimatedCostVes:g,severity:s<=e?"CRITICAL":"REORDER_REQUIRED",isRawMaterial:!0,associatedBomsCount:1},f=new Date().toISOString().replace("T"," ").substring(0,19),h=this.createAlertLog(p,o,void 0,f);return this.sentAlerts.update(u=>[h,...u]),this.saveAlertsToStorage(),this.stateService.notify("success","Email de Alerta Enviado",`Notificaci\xF3n de reorden para ${t.name} enviada exitosamente a ${r.recipients.join(", ")}.`),!0}sendTestEmail(t){let o=this.config(),r=t||o.recipients[0]||"ae.barrios@hotmail.com",n=new Date().toISOString().replace("T"," ").substring(0,19),e={product:{id:"test-prod",sku:"MP-TEST-001",barcode:"7591000999999",name:"Aceite Base Lubricante Sint\xE9tico ISO-68 (PRUEBA)",category:"MATERIA_PRIMA",unit:"LT",costPrice:4.85,salePrice:7.5,prices:{price1:7.5,price2:7,price3:6.5,price4:6.2,price5:5.9},isTaxExempt:!1,taxRate:.16,minStock:50,reorderPoint:120,safetyStock:30,leadTimeDays:7,reorderQuantity:200,totalStock:35,stockByWarehouse:[{warehouseId:"wh-01",warehouseName:"Almac\xE9n Principal",quantity:35}],status:"ACTIVE",updatedAt:n},currentStock:35,reorderPoint:120,minStock:50,deficit:85,suggestedOrderQty:200,estimatedCostUsd:970,estimatedCostVes:970*this.stateService.bcvState().usdRate,severity:"CRITICAL",isRawMaterial:!0,associatedBomsCount:3},a=this.createAlertLog(e,"TEST_EMAIL","TEST-VERIFICATION-001",n,[r]);return this.sentAlerts.update(i=>[a,...i]),this.saveAlertsToStorage(),this.stateService.notify("success","Email de Prueba Enviado",`Mensaje de prueba transmitido v\xEDa ${o.smtpHost}:${o.smtpPort} hacia ${r}.`),!0}createAlertLog(t,o,r,n,e){let a=this.config(),i=e||[...a.recipients],s=n||new Date().toISOString().replace("T"," ").substring(0,19),c="Inspecci\xF3n de Inventario";o==="MRP_CONSUMPTION"&&(c=`Consumo en Fabricaci\xF3n MRP (${r||"Orden de Producci\xF3n"})`),o==="SALE_POS"&&(c=`Despacho / Venta POS (${r||"Factura Fiscal"})`),o==="TEST_EMAIL"&&(c="Prueba de Conectividad SMTP"),o==="MANUAL_TRIGGER"&&(c="Alerta Manual Disparada por Usuario");let d=`[ALERTA MRP] Stock por debajo de Punto de Reorden: ${t.product.sku} - ${t.product.name}`,l=this.generateHtmlTemplate(t,c,i,s,r);return{id:"eml-"+Date.now().toString(36)+"-"+Math.random().toString(36).substring(2,6),timestamp:s,recipients:i,subject:d,productSku:t.product.sku,productName:t.product.name,category:t.product.category,unit:t.product.unit,currentStock:t.currentStock,reorderPoint:t.reorderPoint,minStock:t.minStock,deficitQuantity:t.deficit,suggestedOrderQty:t.suggestedOrderQty,estimatedCostUsd:t.estimatedCostUsd,estimatedCostVes:t.estimatedCostVes,triggerReason:o,orderOrDocRef:r,status:"DELIVERED",previewHtml:l}}generateHtmlTemplate(t,o,r,n,e){let a=this.stateService.bcvState().usdRate,i=t.severity==="CRITICAL",s=i?"#e11d48":"#d97706";return`
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Alerta de Reorden de Inventario MRP - Helameb</title>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 24px; color: #1e293b; }
    .container { max-width: 620px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    .header { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 28px; color: #ffffff; }
    .header h1 { margin: 0; font-size: 20px; font-weight: 700; letter-spacing: -0.5px; }
    .header p { margin: 6px 0 0; font-size: 12px; color: #94a3b8; }
    .badge { display: inline-block; padding: 4px 10px; border-radius: 9999px; font-size: 11px; font-weight: 700; background: ${i?"#ffe4e6":"#fef3c7"}; color: ${i?"#9f1239":"#92400e"}; margin-top: 12px; }
    .content { padding: 28px; }
    .alert-box { background: ${i?"#fff1f2":"#fffbeb"}; border-left: 4px solid ${s}; padding: 14px 18px; border-radius: 8px; margin-bottom: 24px; }
    .alert-box p { margin: 0; font-size: 13px; color: #334155; line-height: 1.5; }
    .product-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin-bottom: 24px; }
    .product-title { font-size: 15px; font-weight: 700; color: #0f172a; margin-bottom: 4px; }
    .product-sku { font-family: monospace; font-size: 12px; color: #64748b; margin-bottom: 14px; }
    .metric-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 12px; }
    .metric-item { background: #ffffff; padding: 10px; border-radius: 8px; border: 1px solid #edf2f7; text-align: center; }
    .metric-label { font-size: 10px; font-weight: 600; text-transform: uppercase; color: #64748b; margin-bottom: 4px; }
    .metric-value { font-size: 16px; font-weight: 700; font-family: monospace; }
    .metric-value.danger { color: ${s}; }
    .metric-value.primary { color: #0f172a; }
    .metric-value.success { color: #059669; }
    .recommendation-table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 12px; }
    .recommendation-table th { text-align: left; padding: 8px 12px; background: #f1f5f9; color: #475569; font-weight: 600; }
    .recommendation-table td { padding: 10px 12px; border-bottom: 1px solid #f1f5f9; color: #1e293b; }
    .cta-button { display: block; width: 100%; box-sizing: border-box; text-align: center; background: #0f172a; color: #ffffff !important; padding: 12px; border-radius: 10px; text-decoration: none; font-weight: 600; font-size: 13px; margin-top: 24px; }
    .footer { padding: 20px 28px; background: #f8fafc; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b; }
    .footer p { margin: 3px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <span style="font-weight: 800; font-size: 14px; letter-spacing: 1px; color: #38bdf8;">NEXUS ERP \u2022 MRP SYSTEM</span>
        <span style="font-size: 11px; color: #94a3b8;">Ref: ${e||"AUT-REORDER"}</span>
      </div>
      <h1 style="margin-top: 10px;">Notificaci\xF3n de Reabastecimiento Autom\xE1tico</h1>
      <p>Generado autom\xE1ticamente por el motor de control de inventario y manufactura MRP.</p>
      <div class="badge">${i?"NIVEL CR\xCDTICO (Bajo Stock M\xEDnimo)":"PUNTO DE REORDEN ALCANZADO"}</div>
    </div>

    <div class="content">
      <div class="alert-box">
        <p><strong>Estimado Equipo de Compras y Producci\xF3n:</strong><br>
        El inventario del insumo <strong>${t.product.name}</strong> ha descendido a <strong>${t.currentStock} ${t.product.unit}</strong>, ubic\xE1ndose por debajo de su Punto de Reorden (${t.reorderPoint} ${t.product.unit}). Se requiere gestionar orden de compra urgente para evitar paradas de producci\xF3n.</p>
      </div>

      <div class="product-card">
        <div class="product-title">${t.product.name}</div>
        <div class="product-sku">SKU: ${t.product.sku} | C\xF3d. Barras: ${t.product.barcode} | Categor\xEDa: ${t.product.category}</div>

        <div class="metric-grid">
          <div class="metric-item">
            <div class="metric-label">Stock Actual</div>
            <div class="metric-value danger">${t.currentStock} ${t.product.unit}</div>
          </div>
          <div class="metric-item">
            <div class="metric-label">Pto. Reorden</div>
            <div class="metric-value primary">${t.reorderPoint} ${t.product.unit}</div>
          </div>
          <div class="metric-item">
            <div class="metric-label">Stock M\xEDnimo</div>
            <div class="metric-value primary">${t.minStock} ${t.product.unit}</div>
          </div>
        </div>
      </div>

      <h3 style="font-size: 13px; color: #0f172a; margin: 0 0 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">Plan de Reposici\xF3n Sugerido por MRP</h3>
      <table class="recommendation-table">
        <tr>
          <th>Par\xE1metro</th>
          <th>Detalle Liquidado</th>
        </tr>
        <tr>
          <td><strong>D\xE9ficit de Inventario</strong></td>
          <td style="color: ${s}; font-weight: 700;">${t.deficit} ${t.product.unit}</td>
        </tr>
        <tr>
          <td><strong>Lote de Compra Sugerido (EOQ)</strong></td>
          <td style="font-weight: 700; color: #059669;">${t.suggestedOrderQty} ${t.product.unit}</td>
        </tr>
        <tr>
          <td><strong>Costo Unitario Promedio</strong></td>
          <td style="font-family: monospace;">$${t.product.costPrice.toFixed(2)} USD (Bs. ${(t.product.costPrice*a).toFixed(2)})</td>
        </tr>
        <tr>
          <td><strong>Presupuesto Estimado de Compra</strong></td>
          <td style="font-weight: 700; font-family: monospace;">$${t.estimatedCostUsd.toFixed(2)} USD / Bs. ${t.estimatedCostVes.toLocaleString("es-VE",{minimumFractionDigits:2})}</td>
        </tr>
        <tr>
          <td><strong>Motivo de Disparo</strong></td>
          <td>${o}</td>
        </tr>
        ${t.associatedBomsCount>0?`
        <tr>
          <td><strong>Impacto en F\xF3rmulas BOM</strong></td>
          <td>Utilizado en ${t.associatedBomsCount} estructura(s) activa(s) de producci\xF3n</td>
        </tr>`:""}
      </table>

      <div style="margin-top: 24px; padding: 12px 16px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; font-size: 12px; color: #166534;">
        <strong>Siguiente Paso Recomendado:</strong> Emitir Orden de Compra formal al proveedor preferencial o programar recepci\xF3n en muelle para el almac\xE9n principal.
      </div>
    </div>

    <div class="footer">
      <p><strong>Destinatarios Notificados:</strong> ${r.join(", ")}</p>
      <p><strong>Fecha y Hora de Emisi\xF3n:</strong> ${n} | Tasa Oficial BCV: Bs. ${a.toFixed(2)} / USD</p>
      <p style="margin-top: 8px; color: #94a3b8;">Helameb Cloud v2.4 \u2022 Servidor SMTP Transaccional: ${this.config().smtpHost}:${this.config().smtpPort}</p>
    </div>
  </div>
</body>
</html>
    `.trim()}seedInitialAlerts(){let t=this.stateService.products(),r=t.filter(s=>s.category==="MATERIA_PRIMA"||s.category==="INSUMOS")[0]||t[0];if(!r)return;let n=this.stateService.bcvState().usdRate,e=new Date(Date.now()-3600*1e3*2).toISOString().replace("T"," ").substring(0,19),a={product:r,currentStock:r.totalStock,reorderPoint:r.minStock*2,minStock:r.minStock,deficit:Math.max(0,r.minStock*2-r.totalStock),suggestedOrderQty:50,estimatedCostUsd:Number((50*r.costPrice).toFixed(2)),estimatedCostVes:Number((50*r.costPrice*n).toFixed(2)),severity:r.totalStock<=r.minStock?"CRITICAL":"REORDER_REQUIRED",isRawMaterial:!0,associatedBomsCount:2},i=this.createAlertLog(a,"MRP_CONSUMPTION","OF-2026-0001",e);this.sentAlerts.set([i]),this.saveAlertsToStorage()}clearAlertLogs(){this.sentAlerts.set([]),this.saveAlertsToStorage(),this.stateService.notify("info","Historial Limpiado","Se ha vaciado el registro de alertas enviadas.")}exportLogsToCsv(){let t=this.sentAlerts();if(t.length===0)return this.stateService.notify("warning","Sin Registros","No existen registros de emails para exportar."),!1;let o=["ID Registro","Fecha y Hora","Destinatarios","Asunto","SKU Producto","Nombre Producto","Categor\xEDa","Stock Actual","Punto Reorden","Stock M\xEDnimo","D\xE9ficit","Cantidad Sugerida Compra","Costo Estimado ($ USD)","Costo Estimado (Bs. BCV)","Motivo Disparo","Documento Ref","Estado Env\xEDo"],r=t.map(e=>[e.id,e.timestamp,`"${e.recipients.join("; ")}"`,`"${e.subject}"`,e.productSku,`"${e.productName}"`,e.category,e.currentStock,e.reorderPoint,e.minStock,e.deficitQuantity,e.suggestedOrderQty,e.estimatedCostUsd.toFixed(2),e.estimatedCostVes.toFixed(2),e.triggerReason,e.orderOrDocRef||"N/A",e.status]),n=new Date().toISOString().split("T")[0];return C(`Alertas_Email_Reorden_MRP_${n}`,o,r)}static \u0275fac=function(o){return new(o||b)};static \u0275prov=x({token:b,factory:b.\u0275fac,providedIn:"root"})};export{E as a};
