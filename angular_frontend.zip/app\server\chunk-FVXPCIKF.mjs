import './polyfills.server.mjs';
function t(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]/g,"")}function i(e,...a){let r=t(e);return r?a.some(n=>n?t(n).includes(r):!1):!0}export{i as a};
